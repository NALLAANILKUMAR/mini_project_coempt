<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                     Online Course Registration 
                </div>

            </div>
        </div>
    </footer>